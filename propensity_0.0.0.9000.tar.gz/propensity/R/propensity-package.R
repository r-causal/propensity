#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stats plogis
#' @importFrom stats qlogis
#' @importFrom stats quantile
#' @importFrom stats uniroot
## usethis namespace: end
NULL
